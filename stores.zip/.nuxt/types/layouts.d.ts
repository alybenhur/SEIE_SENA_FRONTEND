import type { ComputedRef, MaybeRef } from 'vue'

type ComponentProps<T> = T extends new(...args: any) => { $props: infer P } ? NonNullable<P>
  : T extends (props: infer P, ...args: any) => any ? P
  : {}

declare module 'nuxt/app' {
  interface NuxtLayouts {
    admin: ComponentProps<typeof import("C:/2026-1/investigacionsena/frontend/layouts/admin.vue").default>
    coordinador: ComponentProps<typeof import("C:/2026-1/investigacionsena/frontend/layouts/coordinador.vue").default>
    evaluador: ComponentProps<typeof import("C:/2026-1/investigacionsena/frontend/layouts/evaluador.vue").default>
    investigador: ComponentProps<typeof import("C:/2026-1/investigacionsena/frontend/layouts/investigador.vue").default>
    public: ComponentProps<typeof import("C:/2026-1/investigacionsena/frontend/layouts/public.vue").default>
  }
  export type LayoutKey = keyof NuxtLayouts extends never ? string : keyof NuxtLayouts
  interface PageMeta {
    layout?: MaybeRef<LayoutKey | false> | ComputedRef<LayoutKey | false> | {
      [K in LayoutKey]: {
        name?: MaybeRef<K | false> | ComputedRef<K | false>
        props?: NuxtLayouts[K]
      }
    }[LayoutKey]
  }
}